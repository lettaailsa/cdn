module.exports = {
  siteName: "KiraCloud",
  authorName: "yardanshaq",
  profilePicture: "https://kiracloud.my.id/i4mP.png",
  profileBanner: "https://kiracloud.my.id/jkwl.jpg",
  aboutText: "A lightweight platform for hosting files and generating short links effortlessly. Built for speed, reliability, and modern workflow flexibility.",
  backgroundImage: "https://kiracloud.my.id/uzSY.jpg"
};
